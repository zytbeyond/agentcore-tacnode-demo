import json
import urllib3
import os

def lambda_handler(event, context):
    """Translate MCP calls to TACNode API calls"""
    
    tacnode_token = os.environ['TACNODE_TOKEN']
    
    try:
        # Extract MCP request
        if 'body' in event:
            if isinstance(event['body'], str):
                mcp_request = json.loads(event['body'])
            else:
                mcp_request = event['body']
        else:
            mcp_request = event
        
        print(f"Received MCP request: {json.dumps(mcp_request)}")
        
        # Extract method and params
        method = mcp_request.get('method')
        params = mcp_request.get('params', {})
        request_id = mcp_request.get('id', 1)
        
        # Create HTTP client
        http = urllib3.PoolManager()
        
        if method == "tools/call":
            # Handle tools/call - translate to API calls
            tool_name = params.get('name')
            arguments = params.get('arguments', {})
            
            if tool_name == "executeQuery":
                # Execute SQL query via TACNode API
                sql = arguments.get('sql')
                
                # Call TACNode API endpoint for query execution
                api_url = "https://api.tacnode.io/query"
                api_payload = {"sql": sql}
                
                response = http.request(
                    'POST',
                    api_url,
                    body=json.dumps(api_payload),
                    headers={
                        'Authorization': f'Bearer {tacnode_token}',
                        'Content-Type': 'application/json'
                    }
                )
                
                if response.status == 200:
                    api_result = json.loads(response.data.decode('utf-8'))
                    
                    # Return MCP response format
                    mcp_response = {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": json.dumps(api_result)
                                }
                            ],
                            "isError": False
                        }
                    }
                    
                    return {
                        'statusCode': 200,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps(mcp_response)
                    }
                else:
                    error_msg = f'TACNode API error: {response.status}'
                    mcp_error = {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "error": {
                            "code": -32000,
                            "message": error_msg
                        }
                    }
                    return {
                        'statusCode': 200,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps(mcp_error)
                    }
            
            elif tool_name == "listSchemas":
                # List schemas via TACNode API
                api_url = "https://api.tacnode.io/schemas"
                
                response = http.request(
                    'GET',
                    api_url,
                    headers={
                        'Authorization': f'Bearer {tacnode_token}',
                        'Content-Type': 'application/json'
                    }
                )
                
                if response.status == 200:
                    api_result = json.loads(response.data.decode('utf-8'))
                    
                    mcp_response = {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "result": {
                            "content": [
                                {
                                    "type": "text",
                                    "text": json.dumps(api_result)
                                }
                            ],
                            "isError": False
                        }
                    }
                    
                    return {
                        'statusCode': 200,
                        'headers': {'Content-Type': 'application/json'},
                        'body': json.dumps(mcp_response)
                    }
        
        # Default response for unsupported methods
        mcp_error = {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32601,
                "message": f"Method not found: {method}"
            }
        }
        
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps(mcp_error)
        }
            
    except Exception as e:
        print(f"Lambda error: {str(e)}")
        mcp_error = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32603,
                "message": str(e)
            }
        }
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps(mcp_error)
        }
