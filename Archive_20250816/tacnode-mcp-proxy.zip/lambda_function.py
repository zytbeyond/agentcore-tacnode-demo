import json
import urllib3
import os

def lambda_handler(event, context):
    """REAL Lambda proxy for TACNode MCP calls"""
    
    tacnode_token = os.environ['TACNODE_TOKEN']
    tacnode_url = "https://mcp-server.tacnode.io/mcp"
    
    try:
        # Extract MCP request from AgentCore Gateway
        if 'body' in event:
            if isinstance(event['body'], str):
                mcp_request = json.loads(event['body'])
            else:
                mcp_request = event['body']
        else:
            mcp_request = event
        
        print(f"Received MCP request: {json.dumps(mcp_request)}")
        
        # Create HTTP client
        http = urllib3.PoolManager()
        
        # Forward to TACNode MCP server
        response = http.request(
            'POST',
            tacnode_url,
            body=json.dumps(mcp_request),
            headers={
                'Authorization': f'Bearer {tacnode_token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/event-stream'
            }
        )
        
        print(f"TACNode response status: {response.status}")
        
        if response.status == 200:
            # Parse SSE response from TACNode
            response_text = response.data.decode('utf-8').strip()
            print(f"TACNode response: {response_text[:200]}...")
            
            if response_text.startswith('event: message\ndata: '):
                json_data = response_text.replace('event: message\ndata: ', '')
                result = json.loads(json_data)
                
                print(f"Parsed result: {json.dumps(result)}")
                
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'application/json'
                    },
                    'body': json.dumps(result)
                }
            else:
                print(f"Unexpected response format: {response_text[:100]}")
                return {
                    'statusCode': 500,
                    'body': json.dumps({'error': 'Invalid TACNode response format'})
                }
        else:
            error_msg = f'TACNode error: {response.status} - {response.data.decode("utf-8")}'
            print(f"TACNode error: {error_msg}")
            return {
                'statusCode': response.status,
                'body': json.dumps({'error': error_msg})
            }
            
    except Exception as e:
        print(f"Lambda error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
